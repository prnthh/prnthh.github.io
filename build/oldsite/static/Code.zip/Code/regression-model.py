import numpy as np
import matplotlib.pyplot as plt

my_data = np.genfromtxt('runtimesfinal.csv', delimiter=',',dtype='U20')
#my_data.extend(np.genfromtxt('runtimes2.csv', delimiter=',',dtype='U20'))
#my_data.extend(np.genfromtxt('runtimes3.csv', delimiter=',',dtype='U20'))

def reject_outliers(data, m=2):
    return data[abs(data - np.mean(data)) < m * np.std(data)]

gpu = [row for row in my_data if 'gpu' in row[0]]
cpu = [row for row in my_data if 'cpu' in row[0]]
gpuX = []
cpuX = []
gpuy = []
cpuy = []
for row in gpu:
  arr = [np.square(int(row[1])),int(row[2])]
  gpuX.append(arr)
  gpuy.append(float(row[3]))
  
for row in cpu:
  arr = [np.square(int(row[1])),int(row[2])]
  cpuX.append(arr)
  cpuy.append(float(row[3]))

params = [np.square(500), 500]


# example of training a final regression model
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.datasets import make_regression
import pickle

# generate regression dataset

modelCpu = LinearRegression()#PolynomialFeatures(degree = 2) 
modelCpu.fit(cpuX, cpuy)

modelGpu = LinearRegression()#PolynomialFeatures(degree = 2) 
modelGpu.fit(gpuX, gpuy)

pickle.dump(modelCpu, open("model.sav", 'wb'))
pickle.dump(modelGpu, open("model2.sav", 'wb'))