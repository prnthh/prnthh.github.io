#!/bin/bash
testvalues=( 1600 2400 3200 4000 4800 5600 6400 8000 )
echo
echo "Conway's Game of Life Parallel Simulation"
echo "========================================="
echo
echo "========================================="
#for single threaded
echo "Linear Execution Time"
echo
for i in "${testvalues[@]}"
do
echo
echo "size: $i x $i: " `./Linear/gameoflife -r $i -c $i | tr '\n' ' ' | awk 'NF{ print $NF }'`
done
echo
echo "========================================="
#for multiple threaded
echo "openMP Execution Time"
echo
for j in 4 16
do
for i in "${testvalues[@]}"
do
echo
echo "size: $i x $i and threads: $j: " `mpiexec -n $j ./openMP/openmpMasterThreadCommunication/gameoflife -r $i -c $i | tr '\n' ' ' | awk 'NF{ print $NF }'`
done
done
echo
echo "========================================="
#for single host multi processor
echo "MPI Execution Time(Single Host)"
echo
for j in 4 16
do
for i in "${testvalues[@]}"
do
echo "size: $i x $i and threads: $j: " `mpirun -np $j --hosts thispc ~/GameOfLife-MPI-OpenMp-Cuda--master/MPI/gameoflife -r $i -c $i | tr '\n' ' ' | awk 'NF{ print $NF }'`
done
done
echo
echo "========================================="
#for multiple hosts
echo "MPI Execution Time(Multiple Hosts)"
echo
for j in 4 16
do
for i in "${testvalues[@]}"
do
echo "size: $i x $i and threads: $j: " `mpirun -np $j --hosts thispc,nextpc ~/GameOfLife-MPI-OpenMp-Cuda--master/MPI/gameoflife -r $i -c $i | tr '\n' ' ' | awk 'NF{ print $NF }'`
done
done

echo 
echo "========================================="
