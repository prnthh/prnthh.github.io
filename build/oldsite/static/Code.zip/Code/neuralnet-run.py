
import numpy as np
from sklearn import metrics

my_data = np.genfromtxt('runtimesv.csv', delimiter=',',dtype='U20')
#my_data.extend(np.genfromtxt('runtimes2.csv', delimiter=',',dtype='U20'))
#my_data.extend(np.genfromtxt('runtimes3.csv', delimiter=',',dtype='U20'))

def reject_outliers(data, m=2):
    return data[abs(data - np.mean(data)) < m * np.std(data)]

gpu = [row for row in my_data if 'gpu' in row[0]]
cpu = [row for row in my_data if 'cpu' in row[0]]
gpuX = []
cpuX = []
gpuy = []
cpuy = []
for row in gpu:
  arr = [np.square(int(row[1])),int(row[2])]
  gpuX.append(arr)
  gpuy.append(float(row[3]))
  
for row in cpu:
  arr = [np.square(int(row[1])),int(row[2])]
  cpuX.append(arr)
  cpuy.append(float(row[3]))

# load dataset
newcpuX = pd.DataFrame(np.vstack(cpuX))
newcpuY = pd.DataFrame(np.vstack(cpuy))
newgpuX = pd.DataFrame(np.vstack(gpuX))
newgpuY = pd.DataFrame(np.vstack(gpuy))

X = newgpuX
Y = newgpuY


#X = np.array(([2, 9], [1, 5], [3, 6], [9, 3]), dtype=float)
#y = np.array(([290], [150], [360], [1030]), dtype=float)

X = newcpuX
y = newcpuY

Xmax = np.amax(X,axis=0);
ymax = np.amax(y,axis=0);

X = X/np.amax(X,axis=0) # maximum of X array longitudinally 
y = y/ymax

def sigmoid (x): #Sigmoid Function 
	return 1/(1 + np.exp(-x))

def derivatives_sigmoid(x): #Derivative of Sigmoid Function 
	return x * (1 - x)

#Variable initialization
epoch=7000 #Setting training iterations
lr=0.1 #Setting learning rate
inputlayer_neurons = 2 #number of features in data set
hiddenlayer_neurons = 3 #number of hidden layers neurons
output_neurons = 1 #number of neurons at output layer
#weight and bias initialization 
wh=np.random.uniform(size=(inputlayer_neurons,hiddenlayer_neurons)) 
bh=np.random.uniform(size=(1,hiddenlayer_neurons)) 
wout=np.random.uniform(size=(hiddenlayer_neurons,output_neurons)) 
bout=np.random.uniform(size=(1,output_neurons))

for i in range(epoch): #draws a random range of numbers uniformly of dim x*y
#Forward Propogation 
	hinp1=np.dot(X,wh)
	hinp=hinp1 + bh
	hlayer_act = sigmoid(hinp) 
	outinp1=np.dot(hlayer_act,wout) 
	outinp= outinp1+ bout
	output = sigmoid(outinp)
#Backpropagation
	EO = y-output
	outgrad = derivatives_sigmoid(output)
	d_output = EO* outgrad
	EH = d_output.dot(wout.T)
	hiddengrad = derivatives_sigmoid(hlayer_act) #how much hidden layer wts contributed to error
	d_hiddenlayer = EH * hiddengrad
	wout += hlayer_act.T.dot(d_output) *lr # dotproduct of nextlayererror and currentlayerop
	wh += X.T.dot(d_hiddenlayer) *lr

print("Actual Output: \n" + str(y)) 
print("Predicted Output: \n" ,output)
print(metrics.mean_absolute_error(y, output))