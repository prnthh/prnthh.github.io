#!/usr/bin/env python
import subprocess
import sys
#print "size, nIterations, runtime"

numbers = [10, 100, 1000, 10000, 100000, 1000000, 1000000]
f=open("data.txt", "a+")

def run(nIter, size):
    f.write("gpu," + str(size) + "," + str(nIter) + "," + subprocess.check_output(["./cuda/cgol", "p", "0", "s", str(size), "i", str(nIter)]).split(" ")[5]+"\n")
    f.write("cpu," + str(size) + "," + str(nIter) + "," + subprocess.check_output(["./linear/gameoflife", "-r", str(size), "-c", str(size), "-n", str(nIter)]).rstrip("\n\r").split(" ")[2]+"\n")

def printRun(nIter, size):
    print("GPU actual runtime:")
    print("gpu," + str(size) + "," + str(nIter) + "," + subprocess.check_output(["./cuda/cgol", "p", "0", "s", str(size), "i", str(nIter)]).split(" ")[5]+"\n")
    print("CPU actual runtime:")
    print("cpu," + str(size) + "," + str(nIter) + "," + subprocess.check_output(["./linear/gameoflife", "-r", str(size), "-c", str(size), "-n", str(nIter)]).rstrip("\n\r").split(" ")[2]+"\n")

# for size in numbers:
#     for iterations in numbers:
#         run(iterations, size)
#         run(size, iterations)
def CPUscore(input):
    return ((-0.106017990406315) + ((input[0]) * (1.6528767899339434e-05))) + ((input[1]) * (0.017574722773632985))

def GPUscore(input):
    return ((-0.23196982123363857) + ((input[0]) * (4.890566854546176e-07))) + ((input[1]) * (0.0010007958900027725))


if __name__ == "__main__":
        num = [[10000,10000], [100,150], [500,150], [100,500] ]
        if len(sys.argv)>1:
                if "-g" == sys.argv[1]:
                        for i in num:
                                run(i[0], i[1])
                elif "-r" == sys.argv[1]:
                        predRun = [];
                        for i in num:
                                predRun.append(CPUscore([i[0], i[1]]))
                        print("\n\nPredicted runtimes:")
                        print(predRun)
                        

                        if len(sys.argv)>2 and "-s" == sys.argv[2]:
                                zipped = zip(predRun, num)
                                zipped.sort()
                                sorted = [num for (predRun, num) in zipped]
                                print("\n\nJob order:")
                                print(sorted)
                        else:
                                print("\n\nJob order:")
                                print(num)


        else:
                print("Missing args: \n-g to generate data \n-r to predict and run \n-s to use scheduler")